import HttpRequest from './request';

export * from './request';
export default new HttpRequest();
