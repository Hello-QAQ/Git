/// <reference path="./wechat.ts">
declare const wx: Wechat.Wx
declare module '@/api/*'
declare module '@/mixins/*'
declare module '@/utils/*'
declare module '@/libs/*'